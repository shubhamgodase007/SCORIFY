package com.example.cricketmatches;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Class to handle saving and retrieving match history
 */
public class MatchHistory {
    private static final String HISTORY_PATH = "MatchHistory";
    private static DatabaseReference historyRef;
    
    /**
     * Initialize the Firebase reference
     */
    private static void initializeDatabase() {
        if (historyRef == null) {
            historyRef = FirebaseDatabase.getInstance().getReference().child(HISTORY_PATH);
        }
    }
    
    /**
     * Save a match to history
     * 
     * @param matchCode The unique match code
     * @param context Context to show toast messages
     */
    public static void saveMatchToHistory(final String matchCode, final Context context) {
        initializeDatabase();
        
        // First, get the match data from Scorify
        DatabaseReference matchRef = FirebaseDatabase.getInstance().getReference()
                .child("Scorify").child(matchCode);
        
        matchRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Copy this data to the MatchHistory node
                    historyRef.child(matchCode).setValue(dataSnapshot.getValue(), new DatabaseReference.CompletionListener() {
                        @Override
                        public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                            if (databaseError == null) {
                                if (context != null) {
                                    Toast.makeText(context, "Match saved to history successfully", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                if (context != null) {
                                    Toast.makeText(context, "Failed to save match: " + databaseError.getMessage(), 
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });
                } else {
                    if (context != null) {
                        Toast.makeText(context, "Match not found", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                if (context != null) {
                    Toast.makeText(context, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    
    /**
     * Check if a match exists in history
     * 
     * @param matchCode The match code to check
     * @param listener Listener to handle the result
     */
    public static void checkMatchInHistory(String matchCode, final HistoryCheckListener listener) {
        initializeDatabase();
        
        historyRef.child(matchCode).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listener.onResult(dataSnapshot.exists());
            }
            
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                listener.onError(databaseError.getMessage());
            }
        });
    }
    
    /**
     * Listener interface for history checks
     */
    public interface HistoryCheckListener {
        void onResult(boolean exists);
        void onError(String errorMessage);
    }
} 