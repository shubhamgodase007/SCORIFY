package com.example.cricketmatches;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class HomeMenu extends AppCompatActivity {
    
    private static final String TAG = "HomeMenu";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            // Set up window
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            if (getSupportActionBar() != null) {
                getSupportActionBar().hide();
            }
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
    
            // Set layout
            setContentView(R.layout.activity_homepage);
            
            // Initialize app if needed
            AppInitializer.initializeApp(getApplicationContext());
            
        } catch (Exception e) {
            Log.e(TAG, "Error in HomeMenu onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing menu", Toast.LENGTH_SHORT).show();
            
            // Try to continue anyway
            try {
                setContentView(R.layout.activity_homepage);
            } catch (Exception ex) {
                Log.e(TAG, "Fatal error setting layout: " + ex.getMessage(), ex);
                // Nothing more we can do
                finish();
            }
        }
    }

    public void btnStartMatch(View view) {
        try {
            Intent startMatchIntent = new Intent(this, Startmatch.class);
            startActivity(startMatchIntent);
        } catch (Exception e) {
            Log.e(TAG, "Error starting match: " + e.getMessage(), e);
            Toast.makeText(this, "Error starting match", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnMatchCode(View view) {
        try {
            Intent matchcodeIntent = new Intent(this, MatchCode.class);
            startActivity(matchcodeIntent);
        } catch (Exception e) {
            Log.e(TAG, "Error with match code: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening match code screen", Toast.LENGTH_SHORT).show();
        }
    }
    
    public void btnHistory(View view) {
        try {
            Intent historyIntent = new Intent(this, History.class);
            startActivity(historyIntent);
        } catch (Exception e) {
            Log.e(TAG, "Error with history: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening history", Toast.LENGTH_SHORT).show();
        }
    }
    
    public void btnLiveMatches(View view) {
        try {
            Toast.makeText(getApplicationContext(), "Feature Coming Soon...", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e(TAG, "Error with live matches: " + e.getMessage(), e);
        }
    }
    
    public void btnOldMatches(View view) {
        try {
            Intent oldMatchesIntent = new Intent(this, OldMatches.class);
            startActivity(oldMatchesIntent);
        } catch (Exception e) {
            Log.e(TAG, "Error with old matches: " + e.getMessage(), e);
            Toast.makeText(this, "Error opening old matches", Toast.LENGTH_SHORT).show();
        }
    }
}

