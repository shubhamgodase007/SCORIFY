package com.example.cricketmatches;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class History extends AppCompatActivity {
    private static final String TAG = "History";
    private ListView matchesListView;
    private ProgressBar progressBar;
    private TextView emptyView;
    private DatabaseReference historyRef;
    private MatchAdapter adapter;
    private List<Match> matches = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            // Setup window
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            if (getSupportActionBar() != null) {
                getSupportActionBar().hide();
            }
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
                    
            // Setup content view
            setContentView(R.layout.activity_history);
            
            // Initialize Firebase
            if (!AppInitializer.initializeApp(getApplicationContext())) {
                Toast.makeText(this, "Failed to initialize Firebase", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            
            // Initialize references
            historyRef = FirebaseDatabase.getInstance().getReference().child("MatchHistory");
            
            // Initialize UI
            matchesListView = findViewById(R.id.historyListView);
            progressBar = findViewById(R.id.historyProgressBar);
            emptyView = findViewById(R.id.historyEmptyView);
            
            // Set up adapter
            adapter = new MatchAdapter(this, matches);
            matchesListView.setAdapter(adapter);
            
            // Load matches
            loadHistoryMatches();
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing history view", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    
    private void loadHistoryMatches() {
        progressBar.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);
        
        historyRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    matches.clear();
                    
                    for (DataSnapshot matchSnapshot : dataSnapshot.getChildren()) {
                        try {
                            String matchCode = matchSnapshot.getKey();
                            String teamName = matchSnapshot.child("teamname").getValue(String.class);
                            String runs = matchSnapshot.child("runs").getValue(String.class);
                            String wickets = matchSnapshot.child("wickets").getValue(String.class);
                            String overs = matchSnapshot.child("overs").getValue(String.class);
                            String toss = matchSnapshot.child("toss").getValue(String.class);
                            String opted = matchSnapshot.child("opted").getValue(String.class);
                            String matchResult = matchSnapshot.child("matchResult").getValue(String.class);
                            
                            if (matchCode != null) {
                                // Use default values if some fields are missing
                                if (runs == null) runs = "0";
                                if (wickets == null) wickets = "0";
                                if (overs == null) overs = "0.0";
                                if (toss == null) toss = "";
                                if (opted == null) opted = "";
                                if (matchResult == null) matchResult = "";
                                
                                Match match = new Match(matchCode, teamName, runs, wickets, overs, toss, opted, matchResult);
                                matches.add(match);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing match: " + e.getMessage());
                        }
                    }
                    
                    // Update UI
                    adapter.notifyDataSetChanged();
                    progressBar.setVisibility(View.GONE);
                    
                    // Show empty view if needed
                    if (matches.isEmpty()) {
                        emptyView.setVisibility(View.VISIBLE);
                        emptyView.setText("No history matches found");
                    } else {
                        emptyView.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error processing history data: " + e.getMessage(), e);
                    showError("Error loading match history");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Database error: " + databaseError.getMessage());
                showError("Database error: " + databaseError.getMessage());
            }
        });
    }
    
    private void showError(String message) {
        progressBar.setVisibility(View.GONE);
        emptyView.setVisibility(View.VISIBLE);
        emptyView.setText(message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
