package com.example.cricketmatches;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;
import android.app.ProgressDialog;
import androidx.annotation.NonNull;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MatchCode extends AppCompatActivity {
    private DatabaseReference matchRef;
    private ValueEventListener matchListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); // will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); // enable full screen
        setContentView(R.layout.activity_matchcode);
        
        // Disable window animations
        getWindow().setWindowAnimations(0);
    }

    public void btnSubmit(View view) {
        // Disable the button to prevent multiple clicks
        view.setEnabled(false);
        
        EditText mcode = (EditText) findViewById(R.id.evMatchCodeM);
        String matchCode = mcode.getText().toString();

        // Validate the match code
        if (isValidMatchCode(matchCode)) {
            // Show loading dialog
            ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Checking match code...");
            progressDialog.setCancelable(false);
            progressDialog.show();

            matchRef = FirebaseDatabase.getInstance().getReference()
                    .child("Scorify").child(matchCode);

            // Add real-time listener for match updates
            matchListener = new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    progressDialog.dismiss();
                    if (dataSnapshot.exists()) {
                        // Match exists and is active
                        Intent submitIntent = new Intent(MatchCode.this, UserPageScore.class);
                        submitIntent.putExtra("MC", matchCode);
                        submitIntent.putExtra("IS_LIVE", true);
                        submitIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        
                        // Add match data to intent
                        if (dataSnapshot.hasChild("score")) {
                            submitIntent.putExtra("CURRENT_SCORE", dataSnapshot.child("score").getValue(String.class));
                        }
                        if (dataSnapshot.hasChild("overs")) {
                            submitIntent.putExtra("CURRENT_OVERS", dataSnapshot.child("overs").getValue(String.class));
                        }
                        if (dataSnapshot.hasChild("wickets")) {
                            submitIntent.putExtra("CURRENT_WICKETS", dataSnapshot.child("wickets").getValue(String.class));
                        }
                        
                        startActivity(submitIntent);
                        overridePendingTransition(0, 0); // Disable activity transition animation
                    } else {
                        // Check in match history
                        DatabaseReference historyRef = FirebaseDatabase.getInstance().getReference()
                                .child("MatchHistory").child(matchCode);
                        historyRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    Intent historyIntent = new Intent(MatchCode.this, OldMatches.class);
                                    historyIntent.putExtra("MC", matchCode);
                                    historyIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(historyIntent);
                                    overridePendingTransition(0, 0); // Disable activity transition animation
                                } else {
                                    Toast.makeText(MatchCode.this, "Match not found!", Toast.LENGTH_SHORT).show();
                                    mcode.setError("Invalid match code");
                                    mcode.requestFocus();
                                }
                                // Re-enable the button
                                view.setEnabled(true);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Toast.makeText(MatchCode.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                // Re-enable the button
                                view.setEnabled(true);
                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    progressDialog.dismiss();
                    Toast.makeText(MatchCode.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    // Re-enable the button
                    view.setEnabled(true);
                }
            };
            
            // Attach the listener
            matchRef.addValueEventListener(matchListener);
            
        } else {
            Toast.makeText(this, "Please enter a number between 4 and 6 digits.", Toast.LENGTH_SHORT).show();
            mcode.setError("Invalid match code format");
            mcode.requestFocus();
            // Re-enable the button
            view.setEnabled(true);
        }
    }

    private boolean isValidMatchCode(String code) {
        return code != null && !code.isEmpty() && code.matches("\\d{4,6}");
    }

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(0, 0); // Disable transition animation when leaving activity
        // Remove the listener if it exists
        if (matchRef != null && matchListener != null) {
            matchRef.removeEventListener(matchListener);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up the listener
        if (matchRef != null && matchListener != null) {
            matchRef.removeEventListener(matchListener);
        }
    }
}