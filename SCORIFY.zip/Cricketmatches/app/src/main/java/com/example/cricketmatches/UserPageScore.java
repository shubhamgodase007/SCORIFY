package com.example.cricketmatches;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.app.ProgressDialog;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class UserPageScore extends AppCompatActivity {

    private DatabaseReference myref;
    private ValueEventListener valueEventListener;
    private String Teamname = "";
    private String Batsmenname1 = "";
    private String Batsmenname2 = "";
    private String Bowlername = "";
    private String ThisOver1 = "-";
    private String ThisOver2 = "-";
    private String ThisOver3 = "-";
    private String ThisOver4 = "-";
    private String ThisOver5 = "-";
    private String ThisOver6 = "-";
    private String ThisOver7 = "-";
    private String ThisOver8 = "-";
    private String ThisOver9 = "-";
    private String run = "0";
    private String over = "0.0";
    private String wicket = "0";
    private String crr = "0.0";
    private String batFRun = "0";
    private String batSRun = "0";
    private String batFBall = "0";
    private String batSBall = "0";
    private String batFSix = "0";
    private String batSSix = "0";
    private String batFFour = "0";
    private String batSFour = "0";
    private String batFSR = "0.0";
    private String batSSR = "0.0";
    private String bowlrun = "0";
    private String bowlwicket = "0";
    private String bowlmaiden = "0";
    private String bowlover = "0.0";
    private String bowlER = "0.0";
    private String strike = "-";
    private String nstrike = "-";
    private String pshipr = "0";
    private String pshipb = "0";
    private String inning = "1";
    private String toss = "-";
    private String opted = "-";
    private String matchcode;
    private boolean isFirstLoad = true;
    private String previousRun = "0";
    private String previousOver = "0.0";
    private String previousWicket = "0";
    private ProgressDialog progressDialog;
    private String firstInningsScore = "0";
    private String firstInningsWickets = "0";
    private String firstInningsOvers = "0.0";
    private String firstInningsTeam = "";
    private boolean isInningsBreak = false;
    private boolean hasShownTarget = false;
    private String matchCode;
    private DatabaseReference matchRef;
    private ValueEventListener scoreListener;
    
    // UI Elements
    private TextView scoreTextView;
    private TextView oversTextView;
    private TextView wicketsTextView;
    private TextView teamNameTextView;
    private TextView runRateTextView;
    private TextView battingTeamTextView;
    private TextView bowlingTeamTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            if (getSupportActionBar() != null) {
                getSupportActionBar().hide();
            }
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            setContentView(R.layout.activity_userpage);

            // Get match code from intent first
            matchcode = getIntent().getStringExtra("MC");
            if (matchcode == null || matchcode.isEmpty()) {
                showError("Invalid match code!");
                return;
            }

            // Initialize UI elements
            initializeViews();

            // Show loading dialog
            showProgressDialog();

            // Initialize Firebase
            initializeFirebase();

        } catch (Exception e) {
            showError("Error initializing: " + e.getMessage());
        }
    }

    private void initializeViews() {
        scoreTextView = findViewById(R.id.TeamrunU);
        oversTextView = findViewById(R.id.TeamoversU);
        wicketsTextView = findViewById(R.id.TeamwicketU);
        teamNameTextView = findViewById(R.id.Team1U);
        runRateTextView = findViewById(R.id.TeamCRRU);
        battingTeamTextView = findViewById(R.id.tVBatsmenName1U);
        bowlingTeamTextView = findViewById(R.id.tVBowlerNameU);
    }

    private void initializeFirebase() {
        try {
            // Get database instance
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            
            // Create reference to specific match
            myref = database.getReference().child("Scorify").child(matchcode);
            
            // Enable disk persistence for offline capability
            myref.keepSynced(true);

            // Setup real-time listener for score updates
            setupScoreListener();

        } catch (Exception e) {
            showError("Error connecting to database: " + e.getMessage());
        }
    }

    private void setupScoreListener() {
        if (myref == null) {
            showError("Database reference not initialized");
            return;
        }

        valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    if (!dataSnapshot.exists()) {
                        dismissProgressDialog();
                        showError("Match not found");
                        return;
                    }

                    // Update all values from snapshot
                    updateValuesFromSnapshot(dataSnapshot);
                    
                    // Update UI on main thread
                    runOnUiThread(() -> updateUI());

                    // Handle score changes
                    handleScoreChanges(dataSnapshot);

                    // Dismiss progress dialog on first load
                    if (isFirstLoad) {
                        dismissProgressDialog();
                        isFirstLoad = false;
                    }

                } catch (Exception e) {
                    dismissProgressDialog();
                    showError("Error updating data: " + e.getMessage());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                dismissProgressDialog();
                showError("Database Error: " + databaseError.getMessage());
            }
        };

        try {
            // Add value event listener
            myref.addValueEventListener(valueEventListener);
        } catch (Exception e) {
            showError("Error setting up listener: " + e.getMessage());
        }
    }

    private void updateValuesFromSnapshot(DataSnapshot dataSnapshot) {
        try {
            // Update basic match info
            run = getSafeString(dataSnapshot, "run", "0");
            wicket = getSafeString(dataSnapshot, "wicket", "0");
            over = getSafeString(dataSnapshot, "over", "0.0");
            Teamname = getSafeString(dataSnapshot, "teamname", "Team");
            crr = getSafeString(dataSnapshot, "crr", "0.0");
            inning = getSafeString(dataSnapshot, "inning", "1");
            toss = getSafeString(dataSnapshot, "toss", "-");
            opted = getSafeString(dataSnapshot, "opted", "-");

            // Update batsmen info
            batFRun = getSafeString(dataSnapshot, "batFRun", "0");
            batFBall = getSafeString(dataSnapshot, "batFBall", "0");
            batFFour = getSafeString(dataSnapshot, "batFFour", "0");
            batFSix = getSafeString(dataSnapshot, "batFSix", "0");
            batFSR = getSafeString(dataSnapshot, "batFSR", "0.0");
            
            batSRun = getSafeString(dataSnapshot, "batSRun", "0");
            batSBall = getSafeString(dataSnapshot, "batSBall", "0");
            batSFour = getSafeString(dataSnapshot, "batSFour", "0");
            batSSix = getSafeString(dataSnapshot, "batSSix", "0");
            batSSR = getSafeString(dataSnapshot, "batSSR", "0.0");

            // Update bowler info
            bowlover = getSafeString(dataSnapshot, "bowlover", "0.0");
            bowlrun = getSafeString(dataSnapshot, "bowlrun", "0");
            bowlwicket = getSafeString(dataSnapshot, "bowlwicket", "0");
            bowlmaiden = getSafeString(dataSnapshot, "bowlmaiden", "0");
            bowlER = getSafeString(dataSnapshot, "bowlER", "0.0");

            // Update player names
            Batsmenname1 = getSafeString(dataSnapshot, "batsmenname1", "-");
            Batsmenname2 = getSafeString(dataSnapshot, "batsmenname2", "-");
            Bowlername = getSafeString(dataSnapshot, "bowlername", "-");
            strike = getSafeString(dataSnapshot, "strike", "-");
            nstrike = getSafeString(dataSnapshot, "nstrike", "-");

            // Update partnership
            pshipr = getSafeString(dataSnapshot, "pshipr", "0");
            pshipb = getSafeString(dataSnapshot, "pshipb", "0");

            // Update this over
            ThisOver1 = getSafeString(dataSnapshot, "thisOver1", "-");
            ThisOver2 = getSafeString(dataSnapshot, "thisOver2", "-");
            ThisOver3 = getSafeString(dataSnapshot, "thisOver3", "-");
            ThisOver4 = getSafeString(dataSnapshot, "thisOver4", "-");
            ThisOver5 = getSafeString(dataSnapshot, "thisOver5", "-");
            ThisOver6 = getSafeString(dataSnapshot, "thisOver6", "-");
            ThisOver7 = getSafeString(dataSnapshot, "thisOver7", "-");
            ThisOver8 = getSafeString(dataSnapshot, "thisOver8", "-");
            ThisOver9 = getSafeString(dataSnapshot, "thisOver9", "-");

        } catch (Exception e) {
            showError("Error updating values: " + e.getMessage());
        }
    }

    private void updateUI() {
        try {
            // Update score and basic info
            updateTextView(R.id.TeamrunU, run);
            updateTextView(R.id.TeamwicketU, wicket);
            updateTextView(R.id.TeamoversU, over);
            updateTextView(R.id.TeamCRRU, crr);
            updateTextView(R.id.Team1U, Teamname);
            updateTextView(R.id.tVinningU, inning);

            // Update batsmen info
            updateTextView(R.id.tVBatsmenName1U, Batsmenname1);
            updateTextView(R.id.UFBatrun, batFRun);
            updateTextView(R.id.UFBatball, batFBall);
            updateTextView(R.id.UFBatfour, batFFour);
            updateTextView(R.id.UFBatsix, batFSix);
            updateTextView(R.id.UFBatSR, batFSR);
            
            updateTextView(R.id.tVBatsmenName2U, Batsmenname2);
            updateTextView(R.id.USBatrun, batSRun);
            updateTextView(R.id.USBatball, batSBall);
            updateTextView(R.id.USBatfour, batSFour);
            updateTextView(R.id.USBatsix, batSSix);
            updateTextView(R.id.USBatSR, batSSR);

            // Update bowler info
            updateTextView(R.id.tVBowlerNameU, Bowlername);
            updateTextView(R.id.UFbowlover, bowlover);
            updateTextView(R.id.UFbowlrun, bowlrun);
            updateTextView(R.id.UFbowlER, bowlER);
            updateTextView(R.id.UFbowlwicket, bowlwicket);
            updateTextView(R.id.UFbowlmaiden, bowlmaiden);

            // Update partnership
            updateTextView(R.id.tvPartnershipRU, pshipr);
            updateTextView(R.id.tvpartnershipBU, pshipb);

            // Update strike indicators
            updateTextView(R.id.UStrike, strike);
            updateTextView(R.id.UNStrike, nstrike);

            // Update this over balls
            updateTextView(R.id.UTO1, ThisOver1);
            updateTextView(R.id.UTO2, ThisOver2);
            updateTextView(R.id.UTO3, ThisOver3);
            updateTextView(R.id.UTO4, ThisOver4);
            updateTextView(R.id.UTO5, ThisOver5);
            updateTextView(R.id.UTO6, ThisOver6);
            updateTextView(R.id.UTO7, ThisOver7);
            updateTextView(R.id.UTO8, ThisOver8);
            updateTextView(R.id.UTO9, ThisOver9);

            // Update match info
            updateTextView(R.id.teamTossU, toss);
            updateTextView(R.id.ToptedU, opted);

        } catch (Exception e) {
            showError("Error updating UI: " + e.getMessage());
        }
    }

    private void handleScoreChanges(DataSnapshot dataSnapshot) {
        String newRun = getSafeString(dataSnapshot, "run", "0");
        String newWicket = getSafeString(dataSnapshot, "wicket", "0");
        String newOver = getSafeString(dataSnapshot, "over", "0.0");

        // Check for score changes
        if (!newRun.equals(previousRun)) {
            // Run scored
            if (inning.equals("1")) {
                handleFirstInningsEvents(dataSnapshot);
            } else {
                handleSecondInningsEvents(dataSnapshot);
            }
            previousRun = newRun;
        }

        // Check for wicket
        if (!newWicket.equals(previousWicket)) {
            showWicketDialog();
            previousWicket = newWicket;
        }

        // Check for over completion
        if (!newOver.equals(previousOver)) {
            if (newOver.endsWith(".0")) {
                showOverCompleteDialog(newOver);
            }
            previousOver = newOver;
        }
    }

    private void showWicketDialog() {
        runOnUiThread(() -> {
            String message = String.format("WICKET!\n%s: %s/%s (%s)",
                    Teamname, run, wicket, over);
            Toast.makeText(UserPageScore.this, message, Toast.LENGTH_SHORT).show();
        });
    }

    private void showOverCompleteDialog(String completedOver) {
        runOnUiThread(() -> {
            String message = String.format("Over Complete!\n%s: %s/%s (%s)\nCRR: %s",
                    Teamname, run, wicket, completedOver, crr);
            Toast.makeText(UserPageScore.this, message, Toast.LENGTH_SHORT).show();
        });
    }

    private void handleFirstInningsEvents(DataSnapshot dataSnapshot) {
        // Show partnership milestones only on exact multiples of 50
        int partnership = Integer.parseInt(getSafeString(dataSnapshot, "pshipr", "0"));
        if (partnership > 0 && partnership % 50 == 0 &&
                partnership != Integer.parseInt(getSafeString(dataSnapshot, "previousPartnership", "0"))) {
            String partnershipMsg = partnership + " run partnership between " +
                    getSafeString(dataSnapshot, "batsmenname1", "") + " and " +
                    getSafeString(dataSnapshot, "batsmenname2", "");
            Toast.makeText(UserPageScore.this, partnershipMsg, Toast.LENGTH_SHORT).show();
        }

        // Show team score milestones only on exact multiples of 50
        int teamScore = Integer.parseInt(run);
        if (teamScore > 0 && teamScore % 50 == 0 &&
                teamScore != Integer.parseInt(previousRun)) {
            Toast.makeText(UserPageScore.this,
                    Teamname + " reaches " + teamScore + " runs!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void handleSecondInningsEvents(DataSnapshot dataSnapshot) {
        int currentRuns = Integer.parseInt(run);
        int firstInningsTotal = Integer.parseInt(firstInningsScore);
        int targetScore = firstInningsTotal + 1;
        int remainingRuns = targetScore - currentRuns;
        double currentOver = Double.parseDouble(over);
        double totalOvers = 20.0;
        double remainingOvers = totalOvers - currentOver;

        // Update match status
        String matchStatus = "";
        if (remainingRuns > 0 && remainingOvers > 0) {
            matchStatus = String.format("%s needs %d runs from %.1f overs\nRequired RR: %.2f",
                    Teamname, remainingRuns, remainingOvers, remainingRuns/remainingOvers);

            // Show critical situation updates
            if (remainingRuns <= 10 || remainingOvers <= 2.0) {
                showMatchStatusDialog("Crucial Stage", matchStatus);
            }
        }

        // Check for match completion
        if (currentRuns >= targetScore || remainingOvers <= 0 || Integer.parseInt(wicket) >= 10) {
            handleMatchCompletion(currentRuns, targetScore);
        }
    }

    private void handleMatchCompletion(int currentRuns, int targetScore) {
        int remainingWickets = 10 - Integer.parseInt(wicket);
        String matchResult;
        String title;

        if (currentRuns >= targetScore) {
            matchResult = String.format("%s wins by %d wickets!\n\n" +
                            "First Innings: %s - %s/%s (%s)\n" +
                            "Second Innings: %s - %s/%s (%s)",
                    Teamname, remainingWickets,
                    firstInningsTeam, firstInningsScore, firstInningsWickets, firstInningsOvers,
                    Teamname, run, wicket, over);
            title = "Victory!";
        } else {
            int runDifference = targetScore - currentRuns - 1;
            matchResult = String.format("%s wins by %d runs!\n\n" +
                            "First Innings: %s - %s/%s (%s)\n" +
                            "Second Innings: %s - %s/%s (%s)",
                    firstInningsTeam, runDifference,
                    firstInningsTeam, firstInningsScore, firstInningsWickets, firstInningsOvers,
                    Teamname, run, wicket, over);
            title = "Match Complete";
        }

        showWinDialog(title, matchResult);
        disableRefresh();
    }

    private void showWinDialog(String title, String message) {
        runOnUiThread(() -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(UserPageScore.this);
            builder.setTitle(title)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("Share Result", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            shareMatchResult(message);
                        }
                    })
                    .setNegativeButton("Close", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            AlertDialog dialog = builder.create();
            dialog.show();
        });
    }

    private void showToastAndDialog(String title, String message) {
        runOnUiThread(() -> {
            Toast.makeText(UserPageScore.this, message, Toast.LENGTH_SHORT).show();
        });
    }

    private void shareMatchResult(String result) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Cricket Match Result");
        shareIntent.putExtra(Intent.EXTRA_TEXT, result);
        startActivity(Intent.createChooser(shareIntent, "Share match result via"));
    }

    private void disableRefresh() {
        if (myref != null && valueEventListener != null) {
            myref.removeEventListener(valueEventListener);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Don't remove listeners in onPause to maintain live updates
    }

    @Override
    protected void onDestroy() {
        try {
            super.onDestroy();
            // Clean up listeners
            if (myref != null && valueEventListener != null) {
                myref.removeEventListener(valueEventListener);
            }
            dismissProgressDialog();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showInningsBreakDialog() {
        runOnUiThread(() -> {
            String message = String.format("%s Innings Complete!\n\nScore: %s/%s (%s)\n",
                    firstInningsTeam, firstInningsScore, firstInningsWickets, firstInningsOvers);

            AlertDialog.Builder builder = new AlertDialog.Builder(UserPageScore.this);
            builder.setTitle("Innings Break")
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("OK", (dialog, which) -> {
                        dialog.dismiss();
                        // Show target dialog immediately after
                        showTargetDialog();
                    });
            AlertDialog dialog = builder.create();
            dialog.show();
        });
    }

    private void showTargetDialog() {
        runOnUiThread(() -> {
            int target = Integer.parseInt(firstInningsScore) + 1;
            String message = String.format("%s needs %d runs to win\n\nRequired Run Rate: %.2f",
                    Teamname, target, (double)target/20.0);

            AlertDialog.Builder builder = new AlertDialog.Builder(UserPageScore.this);
            builder.setTitle("Target")
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
            AlertDialog dialog = builder.create();
            dialog.show();
        });
    }

    private void showMatchStatusDialog(String title, String message) {
        runOnUiThread(() -> {
            Toast.makeText(UserPageScore.this, message, Toast.LENGTH_LONG).show();
        });
    }

    private void showError(String message) {
        runOnUiThread(() -> {
            try {
                dismissProgressDialog();
                Toast.makeText(UserPageScore.this, message, Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                // If even showing error fails, log to console
                e.printStackTrace();
            }
        });
    }

    private void dismissProgressDialog() {
        try {
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showProgressDialog() {
        try {
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Loading match data...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        } catch (Exception e) {
            showError("Error showing progress: " + e.getMessage());
        }
    }

    // Helper method to safely get string values
    private String getSafeString(DataSnapshot dataSnapshot, String key, String defaultValue) {
        return dataSnapshot.hasChild(key) ? String.valueOf(dataSnapshot.child(key).getValue()) : defaultValue;
    }

    private String getSafeString(DataSnapshot dataSnapshot, String key) {
        return getSafeString(dataSnapshot, key, null);
    }

    private void updateTextView(int viewId, String text) {
        TextView view = findViewById(viewId);
        if (view != null) {
            view.setText(text != null ? text : "");
        }
    }
}