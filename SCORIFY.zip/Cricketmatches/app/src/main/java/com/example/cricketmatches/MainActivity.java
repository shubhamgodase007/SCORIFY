package com.example.cricketmatches;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;
import android.app.ProgressDialog;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private EditText emailTV, passwordTV;
    private Button regBtn;
    private FirebaseAuth mAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            // Set up window first
            requestWindowFeature(Window.FEATURE_NO_TITLE); // will hide the title
            if (getSupportActionBar() != null) {
                getSupportActionBar().hide(); // hide the title bar
            }
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN); // enable full screen

            // Set content view before trying to access UI elements
            setContentView(R.layout.activity_main);

            // Initialize progress dialog
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Please wait...");
            progressDialog.setCancelable(false);

            // Initialize Firebase more directly instead of relying on helper class
            try {
                FirebaseApp.initializeApp(this);
                mAuth = FirebaseAuth.getInstance();
                Log.d(TAG, "Firebase Auth initialized successfully");
            } catch (Exception e) {
                Log.e(TAG, "Firebase Auth initialization failed: " + e.getMessage(), e);
                Toast.makeText(this, "Authentication unavailable", Toast.LENGTH_SHORT).show();
                // Continue to allow login button to work
            }

            // Initialize UI elements
            initializeUI();

            // Set click listeners
            if (regBtn != null) {
                regBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        btnRegister(v);
                    }
                });
            } else {
                Log.e(TAG, "Register button not found in layout");
            }

        } catch (Exception e) {
            Log.e(TAG, "Critical error initializing MainActivity: " + e.getMessage(), e);
            Toast.makeText(this, "Error starting app. Please try again.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Removed automatic redirection to HomeMenu for logged-in users
        // This ensures the login screen always appears
        try {
            Log.d(TAG, "Login screen displayed");
        } catch (Exception e) {
            Log.e(TAG, "Error in onStart: " + e.getMessage(), e);
        }
    }

    private void goToHomeMenu() {
        try {
            Intent intent = new Intent(MainActivity.this, HomeMenu.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        } catch (Exception e) {
            Log.e(TAG, "Error navigating to HomeMenu: " + e.getMessage(), e);
            finish(); // Just finish if navigation fails
        }
    }

    public void btnLogin(View view) {
        try {
            Intent i = new Intent(MainActivity.this, SignUpIntent.class);
            startActivity(i);
        } catch (Exception e) {
            Log.e(TAG, "Error navigating to SignUpIntent: " + e.getMessage(), e);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void btnRegister(View view) {
        try {
            if (mAuth == null) {
                // Try to initialize Firebase again
                try {
                    FirebaseApp.initializeApp(this);
                    mAuth = FirebaseAuth.getInstance();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Login service unavailable. Proceeding as guest.", Toast.LENGTH_LONG).show();
                    goToHomeMenu();
                    return;
                }
            }

            // Validate input fields
            if (emailTV == null || passwordTV == null) {
                Toast.makeText(getApplicationContext(), "Login form error", Toast.LENGTH_LONG).show();
                return;
            }

            String email, password;
            email = emailTV.getText().toString().trim();
            password = passwordTV.getText().toString().trim();

            if (TextUtils.isEmpty(email)) {
                Toast.makeText(getApplicationContext(), "Please enter email...", Toast.LENGTH_LONG).show();
                return;
            }
            if (TextUtils.isEmpty(password)) {
                Toast.makeText(getApplicationContext(), "Please enter password!", Toast.LENGTH_LONG).show();
                return;
            }

            // Show loading dialog
            if (progressDialog != null) {
                progressDialog.setMessage("Logging in...");
                progressDialog.show();
            }

            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            try {
                                if (progressDialog != null && progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }

                                if (task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), "Welcome back!", Toast.LENGTH_LONG).show();
                                    goToHomeMenu();
                                }
                                else {
                                    String errorMsg = task.getException() != null ?
                                            task.getException().getMessage() : "Unknown error";
                                    Toast.makeText(getApplicationContext(), "Login failed: " + errorMsg, Toast.LENGTH_LONG).show();
                                }
                            } catch (Exception e) {
                                Log.e(TAG, "Error handling login completion: " + e.getMessage(), e);
                                if (progressDialog != null && progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }
                            }
                        }
                    });
        } catch (Exception e) {
            Log.e(TAG, "Error in btnRegister: " + e.getMessage(), e);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();

            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        }
    }

    private void initializeUI() {
        try {
            // Finding UI elements by ID
            emailTV = findViewById(R.id.eVLoginIDP);
            passwordTV = findViewById(R.id.eVLoginPass);
            regBtn = findViewById(R.id.ButtonCreateNewAcc);

            // Verify that UI elements were found
            if (emailTV == null) {
                Log.e(TAG, "Email field not found in layout");
            }
            if (passwordTV == null) {
                Log.e(TAG, "Password field not found in layout");
            }
            if (regBtn == null) {
                Log.e(TAG, "Register button not found in layout");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing UI: " + e.getMessage(), e);
        }
    }

    public void btnLoginadmin(View view) {
        try {
            // Skip login and go directly to HomeMenu as guest
            Toast.makeText(this, "Proceeding as guest", Toast.LENGTH_SHORT).show();
            goToHomeMenu();
        } catch (Exception e) {
            Log.e(TAG, "Error in guest login: " + e.getMessage(), e);

            // Direct fallback
            Intent intent = new Intent(MainActivity.this, HomeMenu.class);
            startActivity(intent);
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}
