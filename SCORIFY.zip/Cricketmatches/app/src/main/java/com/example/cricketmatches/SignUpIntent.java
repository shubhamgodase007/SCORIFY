package com.example.cricketmatches;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;
import android.app.ProgressDialog;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class SignUpIntent extends AppCompatActivity {

    private static final String TAG = "SignUpIntent";
    private EditText emailTV, passwordTV;
    private Button loginBtn;
    private FirebaseAuth mAuth;
    private ProgressDialog progressDialog;

    private SignInButton signInButton;
    private GoogleSignInClient mGoogleSignInClient;
    private Button btnSignOut;
    private static final int RC_SIGN_IN = 9001; // Fixed value for sign-in request

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            // Set up window
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            if (getSupportActionBar() != null) {
                getSupportActionBar().hide();
            }
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
                    
            // Set content view
            setContentView(R.layout.activity_newacc);
            
            // Initialize progress dialog
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Please wait...");
            progressDialog.setCancelable(false);
            
            // Initialize Firebase Auth
            try {
                mAuth = FirebaseAuth.getInstance();
                Log.d(TAG, "Firebase Auth initialized successfully");
            } catch (Exception e) {
                Log.e(TAG, "Firebase Auth initialization failed: " + e.getMessage(), e);
                Toast.makeText(this, "Authentication service unavailable", Toast.LENGTH_SHORT).show();
            }
            
            // Initialize UI elements
            initializeUI();
            
            // Set click listener for sign up button
            if (loginBtn != null) {
                loginBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        registerNewUser(v);
                    }
                });
            } else {
                Log.e(TAG, "Sign up button not found");
            }
            
            // Configure Google Sign-In
            try {
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(getString(R.string.default_web_client_id))
                        .requestEmail()
                        .build();
                        
                mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
                
                // Set up Google Sign-In button
                if (signInButton != null) {
                    signInButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            signIn();
                        }
                    });
                }
                
                // Set up sign out button
                if (btnSignOut != null) {
                    btnSignOut.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            signOut();
                        }
                    });
                    
                    // Hide sign out button initially
                    btnSignOut.setVisibility(View.GONE);
                }
                
                Log.d(TAG, "Google Sign-In configured successfully");
            } catch (Exception e) {
                Log.e(TAG, "Failed to configure Google Sign-In: " + e.getMessage(), e);
                // Disable Google Sign-In if configuration fails
                if (signInButton != null) {
                    signInButton.setEnabled(false);
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing sign-up screen", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void signOut() {
        try {
            // Sign out from Google
            mGoogleSignInClient.signOut().addOnCompleteListener(this,
                    task -> {
                        // Sign out from Firebase
                        mAuth.signOut();
                        Toast.makeText(SignUpIntent.this, "You are logged out", Toast.LENGTH_SHORT).show();
                        btnSignOut.setVisibility(View.GONE);
                    });
        } catch (Exception e) {
            Log.e(TAG, "Error signing out: " + e.getMessage(), e);
            Toast.makeText(this, "Error signing out", Toast.LENGTH_SHORT).show();
        }
    }

    private void signIn() {
        try {
            Intent signInIntent = mGoogleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        } catch (Exception e) {
            Log.e(TAG, "Error starting Google sign-in: " + e.getMessage(), e);
            Toast.makeText(this, "Google Sign-In unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        try {
            // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent()
            if (requestCode == RC_SIGN_IN) {
                Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                handleSignInResult(task);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onActivityResult: " + e.getMessage(), e);
            Toast.makeText(this, "Error processing sign-in result", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            
            Log.d(TAG, "Google Sign-in successful, authenticating with Firebase");
            // Signed in successfully, authenticate with Firebase
            firebaseAuthWithGoogle(account);
            
        } catch (ApiException e) {
            // Google Sign-in failed
            Log.w(TAG, "Google sign-in failed", e);
            Toast.makeText(SignUpIntent.this, "Google Sign-in failed: " + e.getStatusCode(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Error handling sign-in result: " + e.getMessage(), e);
            Toast.makeText(this, "Error processing sign-in", Toast.LENGTH_SHORT).show();
        }
    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        if (acct == null) {
            Log.e(TAG, "Google account is null");
            return;
        }
        
        Log.d(TAG, "firebaseAuthWithGoogle:" + acct.getId());
        
        // Show progress dialog
        progressDialog.setMessage("Authenticating with Google...");
        progressDialog.show();
        
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        try {
                            // Dismiss dialog
                            if (progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                            
                            if (task.isSuccessful()) {
                                // Sign in success
                                Log.d(TAG, "signInWithCredential:success");
                                FirebaseUser user = mAuth.getCurrentUser();
                                Toast.makeText(SignUpIntent.this, "Authentication successful", Toast.LENGTH_SHORT).show();
                                updateUI(user);
                                
                                // Navigate to HomeMenu
                                goToHomeMenu();
                            } else {
                                // If sign in fails, display a message to the user
                                Log.w(TAG, "signInWithCredential:failure", task.getException());
                                Toast.makeText(SignUpIntent.this, "Authentication failed", Toast.LENGTH_SHORT).show();
                                updateUI(null);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error in onComplete: " + e.getMessage(), e);
                            if (progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                        }
                    }
                });
    }

    private void updateUI(FirebaseUser user) {
        try {
            if (user != null) {
                // User is signed in
                btnSignOut.setVisibility(View.VISIBLE);
                
                // Get profile information
                String displayName = user.getDisplayName();
                String email = user.getEmail();
                
                // Show a welcome message
                if (!TextUtils.isEmpty(displayName)) {
                    Toast.makeText(this, "Welcome, " + displayName, Toast.LENGTH_SHORT).show();
                } else if (!TextUtils.isEmpty(email)) {
                    Toast.makeText(this, "Signed in as: " + email, Toast.LENGTH_SHORT).show();
                }
            } else {
                // User is signed out
                btnSignOut.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating UI: " + e.getMessage(), e);
        }
    }

    public void registerNewUser(View view) {
        try {
            // Check if Firebase Auth is initialized
            if (mAuth == null) {
                try {
                    mAuth = FirebaseAuth.getInstance();
                } catch (Exception e) {
                    Toast.makeText(this, "Authentication service unavailable", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            
            // Validate form fields
            String email = emailTV.getText().toString().trim();
            String password = passwordTV.getText().toString().trim();
            
            if (TextUtils.isEmpty(email)) {
                emailTV.setError("Email is required");
                emailTV.requestFocus();
                return;
            }
            
            if (TextUtils.isEmpty(password)) {
                passwordTV.setError("Password is required");
                passwordTV.requestFocus();
                return;
            }
            
            if (password.length() < 6) {
                passwordTV.setError("Password must be at least 6 characters");
                passwordTV.requestFocus();
                return;
            }
            
            // Show progress dialog
            progressDialog.setMessage("Creating account...");
            progressDialog.show();
            
            // Create user with email and password
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            // Always dismiss progress dialog
                            if (progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                            
                            try {
                                if (task.isSuccessful()) {
                                    // Registration successful
                                    Log.d(TAG, "createUserWithEmail:success");
                                    Toast.makeText(getApplicationContext(), "Account created successfully!", Toast.LENGTH_SHORT).show();
                                    
                                    // Go to home menu
                                    goToHomeMenu();
                                } else {
                                    // Registration failed
                                    String errorMessage = "Registration failed";
                                    if (task.getException() != null) {
                                        errorMessage = task.getException().getMessage();
                                    }
                                    Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                    Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                                }
                            } catch (Exception e) {
                                Log.e(TAG, "Error in registration completion: " + e.getMessage(), e);
                                Toast.makeText(getApplicationContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
            
        } catch (Exception e) {
            Log.e(TAG, "Error registering user: " + e.getMessage(), e);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        }
    }
    
    private void goToHomeMenu() {
        try {
            Intent intent = new Intent(SignUpIntent.this, HomeMenu.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        } catch (Exception e) {
            Log.e(TAG, "Error navigating to HomeMenu: " + e.getMessage(), e);
        }
    }

    private void initializeUI() {
        try {
            emailTV = findViewById(R.id.eVLoginIDP);
            passwordTV = findViewById(R.id.eVLoginPass);
            loginBtn = findViewById(R.id.ButtonLoginP);
            signInButton = findViewById(R.id.sign_in_button);
            btnSignOut = findViewById(R.id.sign_out_button);
            
            // Hide sign out button initially
            if (btnSignOut != null) {
                btnSignOut.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing UI: " + e.getMessage(), e);
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}
