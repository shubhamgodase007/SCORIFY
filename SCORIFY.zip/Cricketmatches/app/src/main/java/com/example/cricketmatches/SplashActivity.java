package com.example.cricketmatches;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Splash screen activity that appears when the app starts.
 * It will automatically redirect to MainActivity after a brief delay.
 */
public class SplashActivity extends AppCompatActivity {
    
    private static final String TAG = "SplashActivity";
    private static final int SPLASH_TIME_OUT = 2000; // 2 seconds
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            // Set up fullscreen
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            
            // Set content view
            setContentView(R.layout.activity_splash);
            
            Log.d(TAG, "Splash screen started");
            
            // Delayed navigation - simplified for reliability
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        Log.d(TAG, "Starting MainActivity after delay");
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    } catch (Exception e) {
                        Log.e(TAG, "Error navigating from splash: " + e.getMessage(), e);
                        try {
                            // Fallback to HomeMenu
                            Intent intent = new Intent(SplashActivity.this, HomeMenu.class);
                            startActivity(intent);
                            finish();
                        } catch (Exception ex) {
                            Log.e(TAG, "Fatal error: " + ex.getMessage(), ex);
                            Toast.makeText(SplashActivity.this, "Error starting app", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                }
            }, SPLASH_TIME_OUT);
            
        } catch (Exception e) {
            Log.e(TAG, "Error initializing splash: " + e.getMessage(), e);
            // Emergency fallback
            try {
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
            } catch (Exception ex) {
                Log.e(TAG, "Fatal error: " + ex.getMessage(), ex);
            } finally {
                finish();
            }
        }
    }
} 