package com.example.cricketmatches;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

/**
 * Adapter for displaying matches in a ListView
 */
public class MatchAdapter extends ArrayAdapter<Match> {
    
    private Context context;
    private List<Match> matches;
    
    public MatchAdapter(Context context, List<Match> matches) {
        super(context, R.layout.item_match, matches);
        this.context = context;
        this.matches = matches;
    }
    
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.item_match, parent, false);
            
            holder = new ViewHolder();
            holder.matchCodeTextView = convertView.findViewById(R.id.matchCodeTextView);
            holder.teamNameTextView = convertView.findViewById(R.id.teamNameTextView);
            holder.scoreTextView = convertView.findViewById(R.id.scoreTextView);
            
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        
        // Get the current match
        Match match = matches.get(position);
        
        // Set the data
        holder.matchCodeTextView.setText("Match Code: " + match.getMatchCode());
        holder.teamNameTextView.setText("Team: " + match.getTeamName());
        holder.scoreTextView.setText("Score: " + match.getScore());
        
        return convertView;
    }
    
    @Override
    public int getCount() {
        return matches != null ? matches.size() : 0;
    }
    
    /**
     * ViewHolder pattern for better performance
     */
    private static class ViewHolder {
        TextView matchCodeTextView;
        TextView teamNameTextView;
        TextView scoreTextView;
    }
} 