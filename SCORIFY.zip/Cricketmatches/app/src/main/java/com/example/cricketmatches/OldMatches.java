package com.example.cricketmatches;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.util.Log;
import android.app.ProgressDialog;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.ProgressBar;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class OldMatches extends AppCompatActivity {

    private static final String TAG = "OldMatches";
    private EditText matchCodeInput;
    private TextView matchDetailsView;
    private ListView matchesListView;
    private ProgressBar progressBar;
    private DatabaseReference scorifyRef;
    private DatabaseReference historyRef;
    private ProgressDialog progressDialog;
    private List<Match> matchList;
    private MatchAdapter matchAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            // Hide title and enable fullscreen
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            if (getSupportActionBar() != null) {
                getSupportActionBar().hide();
            }
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);

            setContentView(R.layout.activity_old_matches);

            // Initialize progress dialog
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Searching for match...");
            progressDialog.setCancelable(false);

            // Initialize Firebase safely
            if (!AppInitializer.initializeApp(getApplicationContext())) {
                Toast.makeText(this, "Failed to initialize Firebase", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // Initialize Firebase references
            scorifyRef = FirebaseDatabase.getInstance().getReference().child("Scorify");
            historyRef = FirebaseDatabase.getInstance().getReference().child("MatchHistory");

            // Initialize UI elements
            matchCodeInput = findViewById(R.id.matchCodeInput);
            matchDetailsView = findViewById(R.id.matchDetailsView);
            matchesListView = findViewById(R.id.matchesListView);
            progressBar = findViewById(R.id.progressBar);
            Button searchButton = findViewById(R.id.searchButton);
            
            // Initialize match list and adapter
            matchList = new ArrayList<>();
            matchAdapter = new MatchAdapter(this, matchList);
            matchesListView.setAdapter(matchAdapter);
            
            // Set item click listener
            matchesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Match selectedMatch = matchList.get(position);
                    matchDetailsView.setText(selectedMatch.getDetailedDescription());
                }
            });

            // Set search button click listener
            searchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        String matchCode = matchCodeInput.getText().toString().trim();

                        if (matchCode.isEmpty()) {
                            Toast.makeText(OldMatches.this, "Please enter Match Code", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        // Show progress dialog
                        progressDialog.show();

                        // Search match
                        searchMatch(matchCode);
                    } catch (Exception e) {
                        Log.e(TAG, "Error on button click: " + e.getMessage(), e);
                        Toast.makeText(OldMatches.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        if (progressDialog.isShowing()) {
                            progressDialog.dismiss();
                        }
                    }
                }
            });
            
            // Load all matches
            loadAllMatches();
            
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing screen", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    
    private void loadAllMatches() {
        try {
            // Show loading indicator
            progressBar.setVisibility(View.VISIBLE);
            
            // First load matches from history
            loadMatchesFromSource(historyRef, new OnMatchesLoadedListener() {
                @Override
                public void onMatchesLoaded() {
                    // Once history matches are loaded, load active matches
                    loadMatchesFromSource(scorifyRef, new OnMatchesLoadedListener() {
                        @Override
                        public void onMatchesLoaded() {
                            // All matches loaded
                            progressBar.setVisibility(View.GONE);
                        }
                    });
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error loading matches: " + e.getMessage(), e);
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Error loading matches", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void loadMatchesFromSource(DatabaseReference reference, final OnMatchesLoadedListener listener) {
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    // Loop through all matches
                    for (DataSnapshot matchSnapshot : dataSnapshot.getChildren()) {
                        String matchCode = matchSnapshot.getKey();
                        
                        // Get match details safely with null checks
                        Object teamObj = matchSnapshot.child("teamname").getValue();
                        String teamName = (teamObj != null) ? teamObj.toString() : "N/A";
                        
                        Object runObj = matchSnapshot.child("run").getValue();
                        String runs = (runObj != null) ? runObj.toString() : "0";
                        
                        Object wicketObj = matchSnapshot.child("wicket").getValue();
                        String wickets = (wicketObj != null) ? wicketObj.toString() : "0";
                        
                        Object overObj = matchSnapshot.child("over").getValue();
                        String overs = (overObj != null) ? overObj.toString() : "0.0";
                        
                        Object tossObj = matchSnapshot.child("toss").getValue();
                        String toss = (tossObj != null) ? tossObj.toString() : "N/A";
                        
                        Object optedObj = matchSnapshot.child("opted").getValue();
                        String opted = (optedObj != null) ? optedObj.toString() : "N/A";
                        
                        Object resultObj = matchSnapshot.child("matchResult").getValue();
                        String matchResult = (resultObj != null) ? resultObj.toString() : "";
                        
                        // Create match object
                        Match match = new Match(matchCode, teamName, runs, wickets, overs, toss, opted, matchResult);
                        
                        // Add to the list
                        matchList.add(match);
                    }
                    
                    // Update the adapter
                    matchAdapter.notifyDataSetChanged();
                    
                    // Call the callback
                    listener.onMatchesLoaded();
                } catch (Exception e) {
                    Log.e(TAG, "Error processing matches: " + e.getMessage(), e);
                    listener.onMatchesLoaded(); // Call callback anyway to continue flow
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "Database error: " + databaseError.getMessage());
                listener.onMatchesLoaded(); // Call callback anyway to continue flow
            }
        });
    }

    private void searchMatch(final String matchCode) {
        try {
            // First check in the history database
            historyRef.child(matchCode).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    try {
                        if (dataSnapshot.exists()) {
                            // Match found in history, display it
                            displayMatchDetails(dataSnapshot);
                            if (progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                        } else {
                            // Not found in history, check in active matches (Scorify)
                            checkInActiveScorifiy(matchCode);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error processing history data: " + e.getMessage(), e);
                        handleError("Error processing data: " + e.getMessage());
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Log.e(TAG, "History database error: " + databaseError.getMessage());
                    // Continue checking in Scorify even if history lookup failed
                    checkInActiveScorifiy(matchCode);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in searchMatch: " + e.getMessage(), e);
            handleError("Failed to search for match: " + e.getMessage());
        }
    }

    private void checkInActiveScorifiy(final String matchCode) {
        try {
            scorifyRef.child(matchCode).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    try {
                        if (progressDialog.isShowing()) {
                            progressDialog.dismiss();
                        }

                        if (dataSnapshot.exists()) {
                            // Match found in active matches
                            displayMatchDetails(dataSnapshot);
                        } else {
                            // Match not found anywhere
                            matchDetailsView.setText("No match found with this code");
                            Toast.makeText(OldMatches.this, "Match not found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error processing Scorify data: " + e.getMessage(), e);
                        handleError("Error processing data: " + e.getMessage());
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    handleDatabaseError(databaseError);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in checkInActiveScorifiy: " + e.getMessage(), e);
            handleError("Failed to search in active matches: " + e.getMessage());
        }
    }

    private void displayMatchDetails(DataSnapshot dataSnapshot) {
        try {
            // Get match details safely with null checks
            String matchCode = dataSnapshot.getKey();
            
            Object teamObj = dataSnapshot.child("teamname").getValue();
            String teamName = (teamObj != null) ? teamObj.toString() : "N/A";
            
            Object runObj = dataSnapshot.child("run").getValue();
            String runs = (runObj != null) ? runObj.toString() : "0";
            
            Object wicketObj = dataSnapshot.child("wicket").getValue();
            String wickets = (wicketObj != null) ? wicketObj.toString() : "0";
            
            Object overObj = dataSnapshot.child("over").getValue();
            String overs = (overObj != null) ? overObj.toString() : "0.0";
            
            Object tossObj = dataSnapshot.child("toss").getValue();
            String toss = (tossObj != null) ? tossObj.toString() : "N/A";
            
            Object optedObj = dataSnapshot.child("opted").getValue();
            String opted = (optedObj != null) ? optedObj.toString() : "N/A";
            
            Object resultObj = dataSnapshot.child("matchResult").getValue();
            String matchResult = (resultObj != null) ? resultObj.toString() : "";
            
            // Create match object
            Match match = new Match(matchCode, teamName, runs, wickets, overs, toss, opted, matchResult);
            
            // Display match details
            matchDetailsView.setText(match.getDetailedDescription());
            
            // Highlight the match in the list if it exists
            highlightMatchInList(matchCode);
            
        } catch (Exception e) {
            Log.e(TAG, "Error displaying match details: " + e.getMessage(), e);
            matchDetailsView.setText("Error: Could not parse match data");
        }
    }
    
    private void highlightMatchInList(String matchCode) {
        // Find the match in the list and scroll to it
        for (int i = 0; i < matchList.size(); i++) {
            if (matchList.get(i).getMatchCode().equals(matchCode)) {
                matchesListView.setSelection(i);
                break;
            }
        }
    }

    private void handleDatabaseError(DatabaseError databaseError) {
        try {
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            Log.e(TAG, "Database error: " + databaseError.getMessage());
            matchDetailsView.setText("Error fetching match data");
            Toast.makeText(OldMatches.this, "Database Error: " + databaseError.getMessage(),
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Error handling database error: " + e.getMessage(), e);
        }
    }

    private void handleError(String message) {
        try {
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            matchDetailsView.setText("Error: " + message);
            Toast.makeText(OldMatches.this, message, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Error handling error: " + e.getMessage(), e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
    
    /**
     * Interface for callback when matches are loaded
     */
    private interface OnMatchesLoadedListener {
        void onMatchesLoaded();
    }
}
