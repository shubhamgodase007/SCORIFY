package com.example.cricketmatches;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import android.app.ProgressDialog;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Startmatch extends AppCompatActivity {
    static int toss = 1;
    static int opted = 1;
    static String bat = "BAT";
    static String bowl = "BOWL";

    DatabaseReference myref;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); // Hide the title
        getSupportActionBar().hide(); // Hide the title bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); // Enable full screen
        setContentView(R.layout.activity_startmatch);

        // Initialize Firebase Database reference
        myref = FirebaseDatabase.getInstance().getReference().child("Scorify");

        // Initialize progress dialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Validating match code...");
        progressDialog.setCancelable(false);
    }

    public void btnContinue(View view) {
        final EditText eT_HostTeam = findViewById(R.id.eTHostTeamS);
        final EditText eT_vistorTeam = findViewById(R.id.eTVistorTeamS);
        final EditText eT_Overs = findViewById(R.id.eTOversS);
        final EditText evmc = findViewById(R.id.eTMatchCodeS);

        // Validate input fields
        if (isInputValid(eT_HostTeam, eT_vistorTeam, eT_Overs, evmc)) {
            // Show progress dialog
            progressDialog.show();

            // Get match code
            final String matchCode = evmc.getText().toString().trim();

            // Check for duplicate match code in active matches
            myref.child(matchCode).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        // Match code already exists in active matches
                        progressDialog.dismiss();
                        Toast.makeText(Startmatch.this, "Error: Match code already exists", Toast.LENGTH_LONG).show();
                        evmc.setError("This match code is already in use");
                        evmc.requestFocus();
                    } else {
                        // Check in match history as well
                        DatabaseReference historyRef = FirebaseDatabase.getInstance().getReference().child("MatchHistory");
                        historyRef.child(matchCode).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                progressDialog.dismiss();

                                if (dataSnapshot.exists()) {
                                    // Match code exists in history
                                    Toast.makeText(Startmatch.this, "Error: Match code already exists in history", Toast.LENGTH_LONG).show();
                                    evmc.setError("This match code is already in use");
                                    evmc.requestFocus();
                                } else {
                                    // Match code is unique, proceed with match creation
                                    proceedToNextScreen(eT_HostTeam, eT_vistorTeam, eT_Overs, matchCode);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                progressDialog.dismiss();
                                Toast.makeText(Startmatch.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    progressDialog.dismiss();
                    Toast.makeText(Startmatch.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void proceedToNextScreen(EditText eT_HostTeam, EditText eT_vistorTeam, EditText eT_Overs, String matchCode) {
        Intent adminintent = new Intent(this, Playername.class);

        // Set HT and VT based on toss and opted values
        if (toss == 1 && opted == 1) {
            adminintent.putExtra("HT", eT_HostTeam.getText().toString());
            adminintent.putExtra("VT", eT_vistorTeam.getText().toString());
            adminintent.putExtra("TOSS", eT_HostTeam.getText().toString());
            adminintent.putExtra("OPT", bat);
        } else if (toss == 1 && opted == 0) {
            adminintent.putExtra("HT", eT_HostTeam.getText().toString());
            adminintent.putExtra("VT", eT_vistorTeam.getText().toString());
            adminintent.putExtra("TOSS", eT_HostTeam.getText().toString());
            adminintent.putExtra("OPT", bowl);
        } else if (toss == 0 && opted == 1) {
            adminintent.putExtra("HT", eT_vistorTeam.getText().toString());
            adminintent.putExtra("VT", eT_HostTeam.getText().toString());
            adminintent.putExtra("TOSS", eT_vistorTeam.getText().toString());
            adminintent.putExtra("OPT", bat);
        } else if (toss == 0 && opted == 0) {
            adminintent.putExtra("HT", eT_vistorTeam.getText().toString());
            adminintent.putExtra("VT", eT_HostTeam.getText().toString());
            adminintent.putExtra("TOSS", eT_vistorTeam.getText().toString());
            adminintent.putExtra("OPT", bowl);
        }

        adminintent.putExtra("O", eT_Overs.getText().toString());
        adminintent.putExtra("T", Integer.toString(toss));
        adminintent.putExtra("TO", Integer.toString(opted));
        adminintent.putExtra("MC", matchCode);

        startActivity(adminintent);
    }

    private boolean isInputValid(EditText hostTeam, EditText visitorTeam, EditText overs, EditText matchCode) {
        if (hostTeam.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter the Host Team name.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (visitorTeam.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter the Visitor Team name.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (overs.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter the number of Overs.", Toast.LENGTH_SHORT).show();
            return false;
        }
        String matchCodeText = matchCode.getText().toString().trim();
        if (matchCodeText.isEmpty() || !matchCodeText.matches("\\d{4,6}")) {
            Toast.makeText(this, "Match Code must be a number between 4 to 6 digits.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();

        if (view.getId() == R.id.rBtnHostTeam) {
            if (checked) {
                toss = 1;
            }
        } else if (view.getId() == R.id.rBtnVistorTeam) {
            if (checked) {
                toss = 0;
            }
        }
    }

    public void onRadioButtonClicked1(@NonNull View view) {
        boolean checked = ((RadioButton) view).isChecked();

        if (view.getId() == R.id.rBtnBat) {
            if (checked) {
                opted = 1;
            }
        } else if (view.getId() == R.id.rBtnBowl) {
            if (checked) {
                opted = 0;
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}