package com.example.cricketmatches;

/**
 * Model class to represent a cricket match
 */
public class Match {
    private String matchCode;
    private String teamName;
    private String runs;
    private String wickets;
    private String overs;
    private String toss;
    private String opted;
    private String matchResult;

    public Match() {
        // Empty constructor needed for Firebase
    }

    public Match(String matchCode, String teamName, String runs, String wickets, String overs, String toss, String opted, String matchResult) {
        this.matchCode = matchCode;
        this.teamName = teamName;
        this.runs = runs;
        this.wickets = wickets;
        this.overs = overs;
        this.toss = toss;
        this.opted = opted;
        this.matchResult = matchResult;
    }

    public String getMatchCode() {
        return matchCode;
    }

    public void setMatchCode(String matchCode) {
        this.matchCode = matchCode;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getRuns() {
        return runs;
    }

    public void setRuns(String runs) {
        this.runs = runs;
    }

    public String getWickets() {
        return wickets;
    }

    public void setWickets(String wickets) {
        this.wickets = wickets;
    }

    public String getOvers() {
        return overs;
    }

    public void setOvers(String overs) {
        this.overs = overs;
    }

    public String getToss() {
        return toss;
    }

    public void setToss(String toss) {
        this.toss = toss;
    }

    public String getOpted() {
        return opted;
    }

    public void setOpted(String opted) {
        this.opted = opted;
    }

    public String getMatchResult() {
        return matchResult;
    }

    public void setMatchResult(String matchResult) {
        this.matchResult = matchResult;
    }

    public String getScore() {
        return runs + "/" + wickets;
    }

    public String getFormattedScore() {
        return runs + "/" + wickets + " (" + overs + " overs)";
    }

    /**
     * Returns a detailed description of the match
     */
    public String getDetailedDescription() {
        StringBuilder details = new StringBuilder();
        details.append("Match Details:\n\n");
        details.append("Match Code: ").append(matchCode).append("\n");
        details.append("Team: ").append(teamName != null ? teamName : "N/A").append("\n");
        details.append("Score: ").append(getScore()).append("\n");
        details.append("Overs: ").append(overs != null ? overs : "0.0").append("\n");
        details.append("Toss: ").append(toss != null ? toss : "N/A").append("\n");
        details.append("Opted to: ").append(opted != null ? opted : "N/A");
        
        if (matchResult != null && !matchResult.isEmpty()) {
            details.append("\n\nResult: ").append(matchResult);
        }
        
        return details.toString();
    }
} 