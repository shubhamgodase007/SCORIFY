package com.example.cricketmatches;

import android.content.Context;
import android.util.Log;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Utility class to handle app initialization tasks
 */
public class AppInitializer {
    
    private static final String TAG = "AppInitializer";
    private static boolean isInitialized = false;
    
    /**
     * Initialize Firebase and other required services
     * @param context Application context
     * @return true if initialization was successful
     */
    public static boolean initializeApp(Context context) {
        if (isInitialized) {
            Log.d(TAG, "App already initialized, skipping initialization");
            return true;
        }
        
        if (context == null) {
            Log.e(TAG, "Context is null, cannot initialize");
            return false;
        }
        
        try {
            // Initialize Firebase
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context);
                Log.d(TAG, "Firebase initialized successfully");
            } else {
                Log.d(TAG, "Firebase was already initialized");
            }
            
            // Verify the initialization worked by accessing Firebase services
            try {
                FirebaseAuth auth = FirebaseAuth.getInstance();
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                Log.d(TAG, "Firebase services verified");
            } catch (Exception e) {
                Log.e(TAG, "Failed to verify Firebase services: " + e.getMessage(), e);
                // Don't return false here, as the app might still work with some limitations
            }
            
            isInitialized = true;
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error initializing app: " + e.getMessage(), e);
            
            // Try to force initialize Firebase directly
            try {
                FirebaseApp.initializeApp(context);
                Log.d(TAG, "Forced Firebase initialization");
                isInitialized = true;
                return true;
            } catch (Exception e2) {
                Log.e(TAG, "Forced initialization also failed: " + e2.getMessage(), e2);
                return false;
            }
        }
    }
    
    /**
     * Check if Firebase is properly initialized
     * @param context Application context
     * @return true if Firebase is initialized
     */
    public static boolean isFirebaseInitialized(Context context) {
        if (context == null) {
            return false;
        }
        
        try {
            return !FirebaseApp.getApps(context).isEmpty();
        } catch (Exception e) {
            Log.e(TAG, "Error checking Firebase initialization: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Reset initialization state (for testing purposes)
     */
    public static void reset() {
        isInitialized = false;
    }
} 